package org.firstinspires.ftc.teamcode.robotSubSystems.plane;

public enum PlaneStates {
    STOP,THROW
}
