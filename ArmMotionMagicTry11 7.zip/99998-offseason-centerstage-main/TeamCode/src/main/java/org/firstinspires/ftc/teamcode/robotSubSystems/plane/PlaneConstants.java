package org.firstinspires.ftc.teamcode.robotSubSystems.plane;

public class PlaneConstants {
    public static final float stopPose = 0;
    public static final float throwPose = 1;
    public static final float systemAngle = 0.5f;
}
