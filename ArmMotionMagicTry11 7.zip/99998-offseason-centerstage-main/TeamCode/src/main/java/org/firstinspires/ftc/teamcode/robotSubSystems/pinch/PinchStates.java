package org.firstinspires.ftc.teamcode.robotSubSystems.pinch;

public enum PinchStates {
    CLOSED, OPEN,LEFT,RIGHT,INTAKELEFT,INTAKERIGHT
}
