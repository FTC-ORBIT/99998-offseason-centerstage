package org.firstinspires.ftc.teamcode.robotSubSystems.arm;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.OrbitUtils.PID;

public class Arm {
    public static DcMotor armMotor;
    public static float pos;
    public static float currentPos;
    public static float zeroPose;
    public static double wantedPower;
    public static final PID armPID = new PID(ArmConstants.armKp,ArmConstants.armKi,ArmConstants.armKd,ArmConstants.armKf,ArmConstants.armIZone);
    //motion magic 11/7 variable declare
    public static double W_V;
    public static double A_V;
    public static double Magic_Alpha;
    public static double A_Pos;
    public static double Magic_Click_to_rad;
    public static double Pos_A_Rad;
    public static double DT = 3;
    public static double W_Pos;
    public static double Magic_W_Acc;
    public static double Ps;
    public static double Pg;
    public static double Pv;
    //public static final PID Arm_V_PID = new PID(ArmConstants.Motion_Kp,ArmConstants.Motion_Ki,ArmConstants.Motion_Kd,ArmConstants.Motion_Kf,ArmConstants.Motion_I_Zone);
    public static double MotorVelocity;
    public static double Ppid;
    public static double Target_Rad_Pose;

    public static void init(HardwareMap hardwareMap, String name){
    armMotor = hardwareMap.get(DcMotor.class,name);

    armMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
}

public static void operate(ArmStates state, Gamepad gamepad1, Gamepad gamepad2){
     switch (state){
         case GROUND:
             pos = ArmConstants.groundPose;
             break;
         case MIN:
             pos = ArmConstants.minPose;
             break;
         case LOW:
             pos = ArmConstants.lowPose;
             break;
         case MID:
             pos = ArmConstants.midPose;
             break;
         case CLIMB:
             pos = ArmConstants.climbPose;
             break;
         case STACK:
             pos = ArmConstants.stackPose;
             break;
         case TRAVEL:
             pos = ArmConstants.travelPos;
             break;
         case OVERRIDE:
             pos += -gamepad1.right_stick_y * ArmConstants.overrideFactor;
             break;
        }
        //Pose convert to rad
        Target_Rad_Pose = pos / ArmConstants.Click_Per_Rev * (2 * Math.PI);
        //currentPos = armMotor.getCurrentPosition() - zeroPose;
        //sobol PID with rad's instead of ticks
        armPID.setWanted(Target_Rad_Pose);
        wantedPower = (float) armPID.update(Pos_A_Rad);
        wantedPower = (float) Math.min(Math.abs(wantedPower) , ArmConstants.powerLimit) * Math.signum(wantedPower);
    if (wantedPower<0 && currentPos <300) wantedPower =  Math.max (wantedPower,-(Pos_A_Rad / 300));

    //Motion magic functions and variables
    Magic_Alpha = Pos_A_Rad - (ArmConstants.Magic_Arm_Zero / ArmConstants.Click_Per_Rev * (2 * Math.PI));
    A_Pos = Arm.armMotor.getCurrentPosition();
    Magic_Click_to_rad =  Math.PI / (400 - (-400)); //arm horizontal ticks guess
    Pos_A_Rad = (A_Pos - ArmConstants.Magic_Arm_Zero) * Magic_Click_to_rad; //arm vertical ticks guess
    Magic_W_Acc = (W_V - W_V_Prev) / DT;
    W_Pos = W_Pos_Prev + W_V_Prev * DT + Magic_W_Acc * Math.pow(DT, 2);
    Ps = Math.signum(W_V) * ArmConstants.MagicKs;
    Pg = ArmConstants.MagicPg0 * Math.sin(Magic_Alpha);
    Pv = W_V * ArmConstants.Magic_Kv;
    Ppid = ArmConstants.Magic_Kp * (W_Pos - Pos_A_Rad);
    W_V = Math.min(Math.min(W_V_Prev + ArmConstants.Magic_Acc * DT, ArmConstants.Magic_Velocity_Max), Math.sqrt(2 * ArmConstants.Magic_Acc * Math.abs(pos - A_Pos)));

    //Arm_V_PID.setWanted(W_Pos);
    //MotorVelocity = Ps + Pg + Pv + (float) Arm_V_PID.update(Motion_A_Rad);
    //MotorVelocity = Ps + Pg + Pv + (float) Math.min(Math.abs(MotorVelocity), ArmConstants.Motion_Velocity_Max) * Math.signum(MotorVelocity);
    if (Math.abs(Target_Rad_Pose - Pos_A_Rad) < 0.05) W_V = 0;

    MotorVelocity = Ps + Pg + Pv + Ppid;

    armMotor.setPower(wantedPower + MotorVelocity);

        if (gamepad2.left_bumper){
            zeroPose = armMotor.getCurrentPosition();
        }
    }


    public static void test(Gamepad gamepad1, Telemetry telemetry){
    currentPos = armMotor.getCurrentPosition();
    if (gamepad1.b){
        armPID.setWanted(0);
    }else {
        armPID.setWanted(ArmConstants.armTestPos);
    }
    wantedPower = (float) armPID.update(currentPos);
    wantedPower = (float) Math.min(Math.abs(wantedPower) , ArmConstants.powerLimit) * Math.signum(wantedPower);
    if (wantedPower<0 && currentPos <300) wantedPower =  Math.max (wantedPower,-(currentPos / 300));
    armMotor.setPower(wantedPower);
        }



    public static double Pos_Prev_Rad = Pos_A_Rad;
    public static double W_Pos_Prev = W_Pos;
    public static double W_V_Prev = W_V;
    public static double A_V_Prev = A_V;






//    currentPos = armMotor.getCurrentPosition();
//    pos += -gamepad1.right_stick_y * ArmConstants.overrideFactor;
//    armPID.setWanted(pos);
//    armMotor.setPower(armPID.update(currentPos));

    telemetry.addData("arm pose",armMotor.getCurrentPosition());
    telemetry.update();
    }
}
