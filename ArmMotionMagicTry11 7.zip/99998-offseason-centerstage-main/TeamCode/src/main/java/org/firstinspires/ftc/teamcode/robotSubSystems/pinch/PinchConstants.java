package org.firstinspires.ftc.teamcode.robotSubSystems.pinch;

public class PinchConstants {
    public static final float closedPose = 0.45f;
    public static final float closedPose2 = 0.38f;
    public static final float openPose = 0.25f;
    public static final float openPose2 = 0.62f;
}
