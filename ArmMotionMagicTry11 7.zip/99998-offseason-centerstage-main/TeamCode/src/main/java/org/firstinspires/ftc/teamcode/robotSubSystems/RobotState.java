package org.firstinspires.ftc.teamcode.robotSubSystems;

public enum RobotState {
    TRAVEL, INTAKE, LOW,MID,CLIMB, MIN, STACK
}
