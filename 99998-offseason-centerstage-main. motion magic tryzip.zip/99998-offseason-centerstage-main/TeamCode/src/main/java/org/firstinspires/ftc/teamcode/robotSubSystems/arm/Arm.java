package org.firstinspires.ftc.teamcode.robotSubSystems.arm;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.OrbitUtils.PID;

public class Arm {
    public static DcMotor armMotor;
    public static float pos;
    public static float currentPos;
    public static float zeroPose;
    public static float wantedPower;
    public static final PID armPID = new PID(ArmConstants.armKp,ArmConstants.armKi,ArmConstants.armKd,ArmConstants.armKf,ArmConstants.armIZone);
public static void init(HardwareMap hardwareMap, String name){
    armMotor = hardwareMap.get(DcMotor.class,name);

    armMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
}

public static void operate(ArmStates state, Gamepad gamepad1, Gamepad gamepad2){
     switch (state){
         case GROUND:
             pos = ArmConstants.groundPose;
             break;
         case MIN:
             pos = ArmConstants.minPose;
             break;
         case LOW:
             pos = ArmConstants.lowPose;
             break;
         case MID:
             pos = ArmConstants.midPose;
             break;
         case CLIMB:
             pos = ArmConstants.climbPose;
             break;
         case STACK:
             pos = ArmConstants.stackPose;
             break;
         case TRAVEL:
             pos = ArmConstants.travelPos;
             break;
         case OVERRIDE:
             pos += -gamepad1.right_stick_y * ArmConstants.overrideFactor;
             break;
        }
        currentPos = armMotor.getCurrentPosition() - zeroPose;
        armPID.setWanted(pos);
        wantedPower = (float) armPID.update(currentPos);
        wantedPower = (float) Math.min(Math.abs(wantedPower) , ArmConstants.powerLimit) * Math.signum(wantedPower);
    if (wantedPower<0 && currentPos <300) wantedPower =  Math.max (wantedPower,-(currentPos / 300));

    armMotor.setPower(wantedPower);

        if (gamepad2.left_bumper){
            zeroPose = armMotor.getCurrentPosition();
        }
    }
    public static void test(Gamepad gamepad1, Telemetry telemetry){
    currentPos = armMotor.getCurrentPosition();
    if (gamepad1.b){
        armPID.setWanted(0);
    }else {
        armPID.setWanted(ArmConstants.armTestPos);
    }
    wantedPower = (float) armPID.update(currentPos);
    wantedPower = (float) Math.min(Math.abs(wantedPower) , ArmConstants.powerLimit) * Math.signum(wantedPower);
    if (wantedPower<0 && currentPos <300) wantedPower =  Math.max (wantedPower,-(currentPos / 300));
    armMotor.setPower(wantedPower);
        }

    // motion magic
    public static double v_w;
    public static double v_a;
    public static double Motion_Alpha;
    public static double A_Pos = Arm.armMotor.getCurrentPosition();
    public static double Motion_Click_to_rad =  Math.PI /;//ArmPos90 - ArmPos-9
    public static double Motion_A_Rad = (A_Pos - 800) * Motion_Click_to_rad;
    public static double DT;


    double Ps = Math.signum(v_w) * ArmConstants.MotionKs;
    double Pg = ArmConstants.MotionPg0 * Math.sin(Motion_Alpha);
    double Pv = v_w * ArmConstants.Motion_Kv;
    double Ppid = ArmConstants.Motion_P + ArmConstants.Motion_I + ArmConstants.Motion_D;
    double Motor_Power = Ps + Pg + Pv + Ppid;

    public static double W_Pos = W_Pos_Prev + W_V_Prev * DT + A_V_Prev * Math.pow(DT) ;


    double Pos_Prev = Motion_A_Rad;
    public static double W_Pos_Prev = W_Pos;
    public static double W_V_Prev = v_w;
    public static double A_V_Prev = v_a;
    p





//    currentPos = armMotor.getCurrentPosition();
//    pos += -gamepad1.right_stick_y * ArmConstants.overrideFactor;
//    armPID.setWanted(pos);
//    armMotor.setPower(armPID.update(currentPos));

    telemetry.addData("arm pose",armMotor.getCurrentPosition());
    telemetry.update();
    }
}
