package org.firstinspires.ftc.teamcode.robotSubSystems.arm;


import com.acmerobotics.dashboard.config.Config;

@Config
public  class ArmConstants {
    public static final float groundPose = 0;
    public static final float travelPos = 100;
    public static final float minPose = 2100;
    public static final float lowPose = 1800;
    public static final float midPose = 1600;
    public static final float stackPose = 0; // TODO find the pos.
    public static final float climbPose = 0; // TODO find the pos.
    public static final double armTestPos = 400;
    public static final float  overrideFactor = 10;
    public static final double armKp = 0.01f;
    public static final double armKi = 0.000f;
    public static final double armKd = 0.5f;
    public static final double  armKf = 0;
    public static final double armIZone =50f;
    public static final double powerLimit = 0.75;
    public static double MotionKs;
    public static double MotionPg0;
    public static final double motion_Zero;
    public static double Motion_Kv = ;
    public static float Motion_P = 0f;
    public static float Motion_I = 0f;
    public static float Motion_D = 0f; // we need to implement the PID function
    public static float Motion_Velocity_Max = 1;
    // public static double Motion_Click_To_Rad = Math.toRadians(360/1425.1); //clicks to radians
}