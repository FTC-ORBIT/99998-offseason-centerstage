package org.firstinspires.ftc.teamcode.robotSubSystems.arm;

public enum ArmStates {
    GROUND, MIN,LOW,MID,OVERRIDE,CLIMB,STACK,TRAVEL
}
